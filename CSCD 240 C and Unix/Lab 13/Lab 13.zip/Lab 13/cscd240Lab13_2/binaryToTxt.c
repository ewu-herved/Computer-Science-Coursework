#include "FileUtil.h"
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#define MAX_CHARS 100

int main() {

    int fin = 0;
    char buffer[MAX_CHARS];
    //char buffer2[MAX_CHARS];
    int length = 0;
    int x = 0;
    int num = 0;

    fin = open("myBinary.bin", O_RDONLY);

    while (num < 30) {

        read(fin, &length, sizeof(int));
        for (x = 0; x < length; x++) {

            read(fin, buffer, sizeof(char));
        }

        printf("%s\n", buffer);
        num++;
    }

    close(fin);

    return 0;
}

