#include "FileUtil.h"

FILE * openInputFile(char filename[]) {

    FILE * inf = NULL;

    do {

        inf = fopen(filename, "r");

        if (inf == NULL) {

            printf("File not found. Please enter another filename:\n");
            scanf("%s", filename);
        }
    } while(inf == NULL);

    return inf;
}

FILE * promptOpenInputFile() {

    char filename[100];

    FILE *inf = NULL;

    do {

        printf("Please enter the name of an input file: ");

        scanf("%s", filename);

        inf = openInputFile(filename);

        printf("\n\n");

        if (inf == NULL) {

            printf("File not found.");
        }
    } while (inf == NULL);

    return inf;
}

FILE * openOutputFile(char filename[]) {

    FILE * outf = NULL;

    outf = fopen(filename, "w");

    if (outf == NULL) {

        printf("File cannot be overwritten");
        exit(0);
    }

    else {

        return outf;
    }
}

FILE * promptOpenOutputFile() {

    char filename[100];

    FILE *outf = NULL;

    printf("What is the name of the file you would like to write to?\n");

    scanf("%s", filename);

    outf = openOutputFile(filename);

    return outf;
}

int promptOpenBinOutFile() {

    char filename[100];

    int outf = 0;

    printf("What is the name of the file you would like to write to?\n");

    scanf("%s", filename);

    outf = openBinOutFile(filename);

    return outf;
}

int openBinOutFile(char filename[]) {

    int outf = 0;

    outf = open(filename, O_WRONLY);

    if (outf == 0) {

        printf("File cannot be overwritten");
        exit(0);
    }

    else {

        return outf;
    }
}

int promptOpenBinInFile() {

    char filename[100];

    int inf = NULL;

    do {

        printf("Please enter the name of an input file: ");

        scanf("%s", filename);

        inf = openBinInFile(filename);

        printf("\n\n");

        if (inf == 0) {

            printf("File not found.");
        }
    } while (inf == 0);

    return inf;
}

int openBinInFile(char filename[]) {

    int inf = 0;

    do {

        inf = open(filename, O_CREAT | O_WRONLY);

        if (inf == 0) {

            printf("File not found. Please enter another filename:\n");
            scanf("%s", filename);
        }
    } while(inf == 0);

    return inf;
}
