#ifndef FILEUTIL_H_INCLUDED
#define FILEUTIL_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#define MAX 512

FILE * openInputFile(char array[]);

FILE * promptOpenInputFile();

FILE * openOutputFile(char array[]);

FILE * promptOpenOutputFile();

int openBinOutFile(char filename[]);

int promptOpenBinOutFile();

int openBinInFile(char filename[]);

int promptOpenBinInFile();

#endif // FILEUTIL_H_INCLUDED
