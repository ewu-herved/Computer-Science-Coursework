#include "FileUtil.h"
#include <string.h>
#include <unistd.h>

#define MAX_CHARS 100


int main() {

    FILE *fin = NULL;
    int fout = 0;
    //int bfin = 0;
    char buffer[MAX_CHARS];
    int length = 0;

    fin = promptOpenInputFile();
    fout = open("myBinary.bin", O_CREAT|O_WRONLY, 0777);
    //bfin = promptOpenBinInFile();

    while (!feof(fin)) {

        fscanf(fin, "%s", buffer);
        //strcpy(buffer, "test");
        length = strlen(buffer);
        write(fout, &length, sizeof(int));
        write(fout, buffer, length*sizeof(char));
    }

    fclose(fin);
    close(fout);

    return 0;
}

