#include "FileUtil.h"
#include <string.h>
#define MAX_CHARS 100

void strip(char str[]);

int main() {

    FILE *fin = NULL;
    int fout = 0;
    char buffer[MAX_CHARS];
    int length = 0;

    fin = promptOpenInputFile();
    fout = promptOpenBinOutFile();

    while (!feof(fin)) {

        fscanf(fin, "%s", buffer);
        strip(buffer);
        length = strlen(buffer);
        write(fout, &length, sizeof(int));
        write(fout, buffer, length * sizeof(char));
    }

    fclose(fin);
    close(fout);

    return 0;
}

void strip(char str[]) {

    int x = 0;

    while(str[x] != '\r' && str[x] != '\n' && str[x] != '\0') {

        x++;
    }
    str[x] = '\0';
}
