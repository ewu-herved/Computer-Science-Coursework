//Dan Herve
//CSCD 240: Lab 12
//comments in LinkedList.c

#ifndef LIST_H_INCLUDED
#define LIST_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include "hw3.h"



#endif // LIST_H_INCLUDED
