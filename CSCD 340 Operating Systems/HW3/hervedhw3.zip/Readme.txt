The program will read a file called processes.txt for processes. 

Lower numbers are higher priority

It should look as follows:

#processes
processID
TimeStamp
TotalBurstTime
ProcessPriority
processID
TimeStamp
TotalBurstTime
ProcessPriority

etc...

like:

2
1
0
4
2
0
2
1
//end