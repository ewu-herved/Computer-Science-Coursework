#ifndef PIPEIT_H
#define PIPEIT_H

#include "utility.h"

void pipeIt(char ** prePipe, char ** postPipe);
//int fillPipes(Command * command, char ***prePipe, char ***postPipe);

#endif // PIPEIT_H
