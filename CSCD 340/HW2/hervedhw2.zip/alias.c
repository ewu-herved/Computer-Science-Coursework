#include "alias.h"

int makeAlias(Command * com, LinkedList * aliases, int comSize) {

    Alias * alias;
    Node * nn = buildNode();
    char * aliasName;
    int x = 0;

    while(com->comStr[x] != '\'') {

        x++;

        if(com->comStr[x] == '\0' || com->comStr[x] == '\n') {

            printf("Error: invalid alias syntax\n");
            return -1;
        }
    }

    while(com->comStr[x] != '\'') {

        x++;

        if(com->comStr[x] == '\0' || com->comStr[x] == '\n') {

            printf("Error: invalid alias syntax\n");
            return -1;
        }
    }

    alias = (Alias *)calloc(1, sizeof(Alias));

    makeName(&aliasName, com->args->head->next->data);

    alias->name = aliasName;

    alias->command = trimRaw(com->comStr);

    nn->data = alias;

    addLast(aliases, nn);

    return 0;
}

void makeName(char **aliasName, char* rawData) {

    char temp[100];

    strcpy(temp, rawData);

    nameStrip(temp);

    *aliasName = (char*)calloc(strlen(temp) + 1, sizeof(char *));

    strcpy(*aliasName, temp);
}

void nameStrip(char * newName) {

    int x = 0;

    while(newName[x] != '=') {

        x++;
    }
    newName[x] = '\0';
}

Command * trimRaw(char* raw) {

    char buffer[100];
    int x = 0;
    Command * com;

    strcpy(buffer, raw);

    while(buffer[x] != '\'') {

        x++;
    }

    sprintf(buffer, "%.*s", (int)strlen(buffer), buffer + x + 1);

    x = 0;

    while(buffer[x] != '\'') {

        x++;
    }

    buffer[x] = '\0';

    makeCommand(-1, buffer, &com);

    return com;
}

int unalias(LinkedList * aliases, char * name) {

    Node * temp = buildNode();
    temp->data = name;
    int (*f)(Node *, Node *) = compareAl;

    if (removeItem(aliases, temp, f) == -1) {

        return -1;
    }

    return 0;
}

void printAliases(LinkedList * aliases) {

    Node * curr = NULL;
    char** args;
    int argCnt = 0;

    for(curr = aliases->head; curr != NULL; curr = curr->next) {

        Alias * temp = curr->data;

        printf("%s: ", temp->name);

        args = getArgs(temp->command, &argCnt);

        int count = 0;

        for(count = 0; count < temp->command->args->size; count ++) {

            printf("%s ", args[count]);
        }

        freeArgs(args, argCnt);

        argCnt = 0;

        free(args);

        printf("\n");
    }
}

int compareAl(Node * curr, Node * nn) {

    Alias * temp = curr->data;

    return strcmp(temp->name, nn->data);
}

void clearAlias(LinkedList * aliases) {

    Node * curr;

    for(curr = aliases->head; curr != NULL; curr = aliases->head) {

        aliases->head = aliases->head->next;

        Alias * temp = curr->data;

        free(temp->name);
        clearCommand(temp->command);
        free(temp->command);
        free(temp);
        free(curr);
    }
}
