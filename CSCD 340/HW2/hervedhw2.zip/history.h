#ifndef HISTORY_H
#define HISTORY_H

#include "utility.h"

void readHist(LinkedList * history, int histCount);
void writeHist(LinkedList * history, int histFileSize);
void printHistory(LinkedList * history);
void addHistory(LinkedList * history, struct command * com, int histCount, int historyNum);
void trimExc(char * com);
void clearHistory(LinkedList * history);

#endif // HISTORY_H
