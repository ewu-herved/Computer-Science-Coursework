#ifndef COMMANDS_H
#define COMMANDS_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include "utility.h"

typedef struct command{

    int comNum;
    char *comStr;
    LinkedList * args;
} Command;

int makeCommand(int comNum, char *input, Command ** command);
void makeArgs(LinkedList ** args, char *input);
LinkedList * argTok(char *input);
void clearCommand(Command *com);
char **getArgs(Command *com, int * argCnt);
void freeArgs(char ** args, int argCnt);
Node * argNode(LinkedList * myList, char * str);
int fillPipes(Command * command, char ***prePipe, char ***postPipe, int *preArgs, int *postArgs);
void freePipes(char **prePipe, char **postPipe, int preArgs, int postArgs);
void checkAlias(Command ** command, LinkedList * aliases);
LinkedList * copyArgs(Command *com);
void printArgs(Command * com);

#endif // COMMANDS_H
