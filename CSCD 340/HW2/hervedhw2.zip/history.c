#include "history.h"

void readHist(LinkedList * history, int histCount) {

    Command * com;
    int count = 1;

    FILE * fin = NULL;
    char buffer[256];

    fin = fopen(".myshrc_history.bat", "r");

    if (fin == NULL) {

        printf("File could not be opened.");
        return;
    }

    fgets(buffer, 256, fin);

    while (count <= histCount && strcmp(buffer, "\0") != 0 && feof(fin) == 0) {

        if( makeCommand(count, buffer, &com) != -1) {

            addHistory(history, com, histCount, count);

            count++;
        }

        fgets(buffer, 256, fin);
    }

    fclose(fin);
}

void writeHist(LinkedList * history, int histFileSize) {

    int count = 1;
    Node * curr = history->head;
    Command * com = NULL;
    char buffer[256];

    FILE * fin = NULL;

    fin = fopen(".myshrc_history.bat", "w");

    if (fin == NULL) {

        printf("File could not be opened.");
        return;
    }

    while (count <= histFileSize && count <= history->size) {

        com = curr->data;

        sprintf(buffer, "%s\n", com->comStr);

        fputs(buffer, fin);

        count++;
        curr = curr->next;
    }

    fputs("exit\n", fin);
    fclose(fin);
}

void printHistory(LinkedList * history) {

    Node * curr = NULL;

    for(curr = history->head; curr != NULL; curr = curr->next) {

        Command * temp = curr->data;

        printf("%d %s\n", temp->comNum, temp->comStr);
    }
}

void addHistory(LinkedList * history, Command * com, int histCount, int historyNum) {

    Node * nn = buildNode();

    nn->data = com;

    if(historyNum > histCount) {

        Node *curr = history->head;

        history->head = history->head->next;

        Command * temp = curr->data;

        clearCommand(temp);
        free(temp);
        free(curr);
    }

    addLast(history, nn);
}

void trimExc(char * com) {

    int count = 0;

    while(com[count] == '!') {

        count++;
    }

    sprintf(com, "%.*s", (int)strlen(com) - count, com + count);
}

void clearHistory(LinkedList * history) {

    Node * curr;

    for(curr = history->head; curr != NULL; curr = history->head) {

        history->head = history->head->next;

        Command * temp = curr->data;

        clearCommand(temp);
        free(temp);
        free(curr);
    }
}
