#ifndef UTILITY_H
#define UTILITY_H

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include "linkedList.h"
#include "pipeIt.h"
#include "commands.h"
#include "alias.h"
#include "history.h"

void readSh(char ** path, int * histCount, int * histFileCount, LinkedList * aliases);
void strip(char *s);
void cleanArray(int size, char **array);
void forkIt(char ** argv);
int isPath(char* s);
void setPath(char ** path, char * add);

#endif // UTILITY_H
