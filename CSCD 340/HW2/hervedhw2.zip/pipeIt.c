#include "pipeIt.h"

void pipeIt(char ** prePipe, char ** postPipe) {

    pid_t pid;
    pid_t child_id;
    int fd[2];
    int * status;
    if((child_id = fork()) == 0) {

        if (pipe(fd) < 0) {

            printf("Error: failed to open file descriptors\n");
            exit(-1);
        }

        if (pid = fork() == 0) {

            close(fd[0]);
            close(1);
            dup(fd[1]);
            if (execvp(prePipe[0], prePipe) < 0) {
                printf("Error: Child exec failed.\n");
                exit(-1);
            }
        }
        else if (pid < 0) {

            printf("Error: fork returning bad pid\n");
            exit(-1);
        }
        else {

            close(fd[1]); //we want to control the read in in case we�re not ready for it
            close(0); //we don�t want to write to actual stdout
            dup(fd[0]); //points to stdout
            //close(fd[1]); //stdout is now pointing here, so fd[1] is not needed
            if (execvp(postPipe[0], postPipe) < 0) {
                printf("Error: Parent exec failed.\n");
                exit(-1);
            }
        }
    }
    else {

        wait(&status);
    }
}// end pipeIt

//int fillPipes(Command * command, char ***prePipe, char ***postPipe) {
//
//    Node * curr;
//    LinkedList * list = command->args;
//    int preArgs = 0, postArgs = 0, pipeFlag = 0;
//
//    for(curr = list->head; curr != NULL; curr = curr->next) {
//
//        if (strcmp(curr->data, "|") != 0);
//        else {
//            pipeFlag = -1;
//        }
//
//        if (pipeFlag == 0) {
//            preArgs++;
//        }
//        else if(pipeFlag == -1) {
//            pipeFlag = 1;
//        }
//        else{
//            postArgs++;
//        }
//    }
//
//    if(preArgs == 0) { //check to see if no commands were entered
//
//        printf("Error: no string entered\n\n");
//        return -1;
//    }
//
//    (*prePipe) = (char**)calloc(preArgs + 1, sizeof(char*)); //****************
//
//    if (postArgs > 0)
//        (*postPipe) = (char**)calloc(postArgs + 1, sizeof(char*));//*****************
//
//    int count = 0;
//
//    for(curr = list->head; curr != NULL; curr = curr->next) {
//
//        if(preArgs > 0) {
//
//            (*prePipe)[count] = (char*)calloc(strlen(curr->data) + 1, sizeof(char)); //**************
//            strcpy((*prePipe)[count], curr->data);
//            preArgs--;
//            count++;
//            if (preArgs == 0) {
//                count = 0;
//            }
//        }
//        else if(postArgs > 0) {
//
//            (*postPipe)[count] = (char*)calloc(strlen(curr->data) + 1, sizeof(char));
//            strcpy((*postPipe)[count], curr->data);
//            postArgs--;
//            count++;
//        }
//    }
//
//    return 0;
//}
