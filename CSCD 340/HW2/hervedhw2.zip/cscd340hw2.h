#ifndef CSCD340HW2_H
#define CSCD340HW2_H

#include "utility.h"



#endif // CSCD340HW2_H
