#include "utility.h"

void readSh(char ** path, int * histCount, int * histFileCount, LinkedList * aliases) {

    FILE * fin = NULL;
    char buffer[100];
    Command * com;

    fin = fopen(".myshrc.bat", "r");

    if (fin == NULL) {

        printf("File could not be opened.");
        return;
    }

    fgets(buffer, 100, fin);
    strip(buffer);

    setPath(path, buffer);

    fscanf(fin, "%s", buffer);

    int x = 0;

    while(buffer[x] != '=' && buffer[x] != '\n') {

        x++;
    }

    sprintf(buffer, "%.*s", (int)strlen(buffer) - x - 1, buffer + x + 1);

    *histCount = strtol(buffer, NULL, 10);

    fscanf(fin, "%s", buffer);

    x = 0;

    while(buffer[x] != '=' && buffer[x] != '\n') {

        x++;
    }

    sprintf(buffer, "%.*s", (int)strlen(buffer) - x - 1, buffer + x + 1);

    *histFileCount = strtol(buffer, NULL, 10);

    fgets(buffer, 100, fin);
    fgets(buffer, 100, fin);

    do {

        fgets(buffer, 100, fin);

        strip(buffer);

        if (strcmp(buffer, "\0") != 0 && strcmp(buffer, "end") != 0) {

            makeCommand(-1, buffer, &com);
            makeAlias(com, aliases, com->args->size);
            clearCommand(com);
            free(com);
        }

    } while (strcmp(buffer, "end") != 0);//(feof(fin) != 0);

    fclose(fin);
}

void strip(char *s) {

    int x = 0;

    if(s == NULL) {

        return;
    }

    while(s[x] != '\r' && s[x] != '\n' && s[x] != '\0') {

        x++;
    }
    s[x] = '\0';

    if (s[0] == ' ') {

        x = 1;

        while(s[x] == ' ') {

            x++;
        }

        sprintf(s, "%.*s", (int)strlen(s) - x, s + x);
    }
}// end strip

void cleanArray(int size, char **array) {

    int count = 0;

    for(count = 0; count < size; count++) {

        free(array[count]);
    }
}

void forkIt(char ** argv) {

    int status;
    pid_t pid = fork();

    if(pid < 0) {

        printf("Error: forking failed\n");
        exit(-1);;
    }

    else if(pid != 0) { //not child

        waitpid(-1, &status, 0);
    }

    else {

        if (execvp(argv[0], argv) < 0) {

            printf("Error: exec failed\n");
            exit(-1);
        }
    }
}// end forkIt

int isPath(char* s) {

    //char buffer[256];
    char temp[20];
    int x = 0;

    strip(s);

    while(s[x] != ':' && s[x] != '\0' && s[x] != '\n' && x < 12) {

        x++;
    }

    sprintf(temp, "%.*s", 11, s);

    if(strcmp(temp, "PATH=$PATH:") == 0) {

        return 1;
    }

    return 0;
}

void setPath(char ** path, char * add) {

    char buffer[256];
    int x = 1;
    char * newPath;

    while(add[x] != ':') {

        x++;
    }

    if(*path == NULL) {

        sprintf(buffer, "%.*s", (int)strlen(add) - x - 1, add + x + 1);

        newPath = (char*)calloc(strlen(buffer) + 1, sizeof(char));

        strcpy(newPath, buffer);
    }

    else {

        sprintf(buffer, "%.*s", (int)strlen(add) - x, add + x);

        newPath = (char*)calloc(strlen(buffer) + 1 + strlen(*path), sizeof(char));

        strcpy(newPath, *path);
        strcat(newPath, buffer);
    }

    *path = newPath;
}
