#ifndef ALIAS_H
#define ALIAS_H

#include "utility.h"
#include "commands.h"

typedef struct alias {

    char * name;
    struct command * command;
} Alias;

int makeAlias(struct command * com, LinkedList * aliases, int comSize);
void makeName(char ** aliasName, char* rawData);
void nameStrip(char *);
struct command * trimRaw(char* raw);
int unalias(LinkedList * aliases, char * name);
void printAliases(LinkedList * aliases);
int compareAl(Node * curr, Node * nn);
void clearAlias(LinkedList * aliases);

#endif // ALIAS_H
