#include "commands.h"
#include "linkedList.h"

int makeCommand(int num, char *input, Command ** command) {

    char buffer[256];

    strcpy(buffer, input);

    strip(buffer);

    if (strcmp(buffer, "\0") == 0 || strcmp(buffer, "") == 0) {

        return -1;
    }

    *command = (Command *)calloc(1, sizeof(Command));

    (*command)->comNum = num;
    (*command)->comStr = (char *)calloc(strlen(buffer) + 1, sizeof(char));
    strcpy((*command)->comStr, buffer);
    makeArgs(&(*command)->args, (*command)->comStr);

    return 0;
}

void makeArgs(LinkedList ** args, char *input) {

    (*args) = argTok(input);
}

LinkedList * argTok(char *input) {

    int count = 1;
    char buffer[100];
    char tempArg[100];
    LinkedList * tempList = linkedList();

    strcpy(buffer, input);

    while (buffer[count - 1] != '\0') {

        if(buffer[count] == ' ' || buffer[count] == '\0') {

            sprintf(tempArg, "%.*s", count, buffer);
            strip(tempArg);
            addLast(tempList, argNode(tempList, tempArg));
            sprintf(buffer, "%.*s", (int)strlen(buffer), buffer + count);
            strip(buffer);
            count = 1;
        }

        else if(buffer[count] == '|' || buffer[count] == '<' || buffer[count] == '>') {

            sprintf(tempArg, "%.*s", count, buffer);
            strip(tempArg);
            addLast(tempList, argNode(tempList, tempArg));
            sprintf(buffer, "%.*s", (int)strlen(buffer), buffer + count);
            strip(buffer);
            count = 1;
        }

        else {

            count++;
        }
    }

    return tempList;
}

void clearCommand(Command *com) {

    LinkedList * temp = NULL;

    free(com->comStr);
    temp = com->args;
    while (temp->size > 0) {

        char * tempArg = removeFirst(temp);
        free(tempArg);
    }

    free(temp);
}

char **getArgs(Command *com, int * argCnt) {

    int count = 0;
    LinkedList * list = com->args;
    char * arg;
    Node * curr;

    char **argv = (char**)calloc(list->size + 1, sizeof(char*));

    for(curr = list->head; count < list->size; count++, curr = curr->next) { //depopulate comToks and populate argv with popped nodes

        arg = (char *)curr->data;
        argv[count] = (char*)calloc(strlen(arg) + 1, sizeof(char));
        strcpy(argv[count], arg);
        (*argCnt)++;
    }

    return argv;
}

void freeArgs(char ** args, int argCnt) {

    int count = 0;

    for(count = 0; count < argCnt; count++) {

        free(args[count]);
    }
}

Node * argNode(LinkedList * myList, char * str){

    char * temp;

    Node * node = buildNode();
    temp = (char*)calloc(strlen(str) + 1, sizeof(char));
    strcpy(temp, str);
    node->data = temp;
    return node;
}

int fillPipes(Command * command, char ***prePipe, char ***postPipe, int *preArgs, int *postArgs) {

    Node * curr;
    LinkedList * list = command->args;
    int pipeFlag = 0;
    *preArgs = 0, *postArgs = 0;

    for(curr = list->head; curr != NULL; curr = curr->next) {

        if (strcmp(curr->data, "|") != 0);
        else {
            pipeFlag = -1;
        }

        if (pipeFlag == 0) {
            (*preArgs)++;
        }
        else if(pipeFlag == -1) {
            pipeFlag = 1;
        }
        else{
            (*postArgs)++;
        }
    }

    int preTemp = *preArgs, postTemp = *postArgs;

    (*prePipe) = (char**)calloc(*preArgs + 1, sizeof(char*)); //****************

    if (*postArgs > 0)
        (*postPipe) = (char**)calloc(*postArgs + 1, sizeof(char*));//*****************

    int count = 0;

    for(curr = list->head; curr != NULL; curr = curr->next) {

        if(preTemp > 0) {

            (*prePipe)[count] = (char*)calloc(strlen(curr->data) + 1, sizeof(char)); //**************
            strcpy((*prePipe)[count], curr->data);
            preTemp--;
            count++;
            if (preTemp == 0) {
                count = 0;
            }
        }

        else if(preTemp == 0 && pipeFlag == 1) {

            pipeFlag = 0;
        }

        else if(postTemp > 0) {

            (*postPipe)[count] = (char*)calloc(strlen(curr->data) + 1, sizeof(char));
            strcpy((*postPipe)[count], curr->data);
            postTemp--;
            count++;
        }
    }

    return 0;
}

void freePipes(char **prePipe, char **postPipe, int preArgs, int postArgs) {

    int count;

    for(count = 0; count < preArgs; count++) {

        free(prePipe[count]);
    }

    for(count = 0; count < postArgs; count++) {

        free(postPipe[count]);
    }
}

void checkAlias(Command ** com, LinkedList * aliases) {

    Node * curr = NULL;
    Node * prev = (*com)->args->head;
    Node * currAl = NULL;
    Node * currArg = NULL;
    Node * tail = NULL;

    for(curr = (*com)->args->head; curr != NULL; prev = curr, curr = curr->next) {

        for(currAl = aliases->head; currAl != NULL; currAl = currAl->next) {

            Alias * temp = currAl->data;

            if (strcmp(curr->data, temp->name) == 0) {

                LinkedList * newList = copyArgs(temp->command);

                for(currArg = newList->head; currArg->next != NULL; currArg = currArg->next);

                tail = currArg;

                if (prev == (*com)->args->head) {

                    (*com)->args->head = newList->head;

                    tail->next = curr->next;

                    free(prev->data);
                    free(prev);
                }

                else {

                    Node * trash = prev->next;

                    prev->next = newList->head;

                    tail->next = curr->next;

                    free(trash->data);
                    free(trash);
                }

                free(newList);

                curr = tail;
            }
        }
    }
}

LinkedList * copyArgs(Command *com) {

    LinkedList * newList = linkedList();
    Node * curr = NULL;

    for(curr = com->args->head; curr != NULL; curr = curr->next) {

        Node * nn = buildNode();
        char * temp = (char*)calloc(strlen((char*)(curr->data)) + 1, sizeof(char));
        strcpy(temp, (char*)(curr->data));
        nn->data = temp;
        addLast(newList, nn);
    }

    return newList;
}

void printArgs(Command * com) {

    Node * curr = NULL;

    for(curr = com->args->head; curr != NULL; curr = curr->next) {

        char * temp = curr->data;

        printf("%s\n", temp);
    }
}
