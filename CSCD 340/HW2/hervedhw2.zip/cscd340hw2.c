#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cscd340hw2.h"

#define MAX 100


int main()
{
	char s[MAX];
	int historyNum = 0;
	Command * com = NULL;
	char ** prePipe = NULL;
	char ** postPipe = NULL;
	LinkedList * aliases = (LinkedList *)calloc(1, sizeof(LinkedList));
	LinkedList * history = (LinkedList *)calloc(1, sizeof(LinkedList));
	char * path = NULL;
	int histCount = 0;
	int histFileCount = 0;

	readSh(&path, &histCount, &histFileCount, aliases);
	readHist(history, histCount);
	historyNum = history->size;

	printf("?: ");
	fgets(s, MAX, stdin);

 	while(strcmp(s, "exit\n") != 0) {

		historyNum++;

		if (makeCommand(historyNum, s, &com) == -1) {

            printf("Error: Invalid command\n");
            while(getchar() != '\n');
		}

		else if (isPath(s) == 1) {

            setPath(&path, s);
            execl(NULL, s, NULL);
		}

		else {

            if (((char*)com->args->head->data)[0] == '!') {

                if (((char*)com->args->head->data)[1] == '!') {

                    Node * curr;

                    for(curr = history->head; curr->next != NULL; curr = curr->next);

                    Command * temp = curr->data;

                    strcpy(s, temp->comStr);

                    clearCommand(com);

                    free(com);

                    makeCommand(historyNum, s, &com);
                }

                else {

                    Node * curr;

                    char * firstArg = com->args->head->data;

                    trimExc(firstArg);

                    int histCall = strtol(firstArg, NULL, 10);

                    int count = 1;

                    for(curr = history->head; count < histCall; curr = curr->next, count++);

                    Command * temp = curr->data;

                    strcpy(s, temp->comStr);

                    clearCommand(com);

                    free(com);

                    makeCommand(historyNum, s, &com);
                }
            }

            addHistory(history, com, histCount, historyNum);

            if (strcmp(com->args->head->data, "alias") == 0) {

                if (com->args->head->next == NULL) {

                    printAliases(aliases);
                }

                else {

                    makeAlias(com, aliases, com->args->size);
                }
            }

            else if (strcmp(com->args->head->data, "unalias") == 0) {

                unalias(aliases, (char*)com->args->head->next->data);
            }

            else if (strcmp(com->args->head->data, "history") == 0) {

                printHistory(history);
            }

            else if (strcmp(com->args->head->data, "cd") == 0) {

                char buffer[256];

                strcpy(buffer, com->args->head->next->data);

                if (chdir(buffer) == -1) {

                    printf("Error: incorrect pathname\n");
                }
            }

            else {

                checkAlias(&com, aliases);

                int preArgs, postArgs;

                fillPipes(com, &prePipe, &postPipe, &preArgs, &postArgs);

                if(postPipe != NULL) {

                    pipeIt(prePipe, postPipe);
                }

                else if(strcmp(prePipe[0], "echo") == 0 && strcmp(prePipe[1], "$PATH") == 0) {

                    printf("%s\n", path);
                }

                else {

                    forkIt(prePipe);
                }

                freePipes(prePipe, postPipe, preArgs, postArgs);
                free(prePipe);
                free(postPipe);
                prePipe = NULL;
                postPipe = NULL;
            }
		}

		printf("?: ");
        fgets(s, MAX, stdin);
	}// end while

    writeHist(history, histFileCount);
    clearAlias(aliases);
    clearHistory(history);
    free(aliases);
    free(history);
    free(path);
	return 0;

}// end main


