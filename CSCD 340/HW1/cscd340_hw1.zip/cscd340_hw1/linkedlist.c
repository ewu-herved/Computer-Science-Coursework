//Dan Herve
//CSCD 340: HW1

#include "linkedlist.h"

LinkedList * linkedList(){ //Make a LinkedList

    return (LinkedList*)calloc(1, sizeof(LinkedList));
}

Node * buildNode(){

    char buffer[100];
    Node * nn = (Node*)calloc(1, sizeof(Node));

    printf("What word would you like to add or remove: ");

    scanf("%s", buffer);

    nn->data = buffer;

    return nn;
}

//void sort(LinkedList * myList){//selection sort
//
//    Node *curr;
//    Node *prev;
//    int smallest = 0;
//    int temp = 0;
//
//    if(myList->size == 0);
//
//    for(prev = myList->head; prev != NULL; prev = prev->next) {
//
//        smallest = prev->data;
//
//        for(curr = prev->next; curr != NULL; curr = curr->next) {
//
//            if(smallest > curr->data) {
//
//                temp = smallest;
//                smallest = curr->data;
//                prev->data = smallest;
//                curr->data = temp;
//            }
//        }
//    }
//}

void clearList(LinkedList * theList){ //free the Nodes

    Node *curr;

    if(theList->size == 0);
    else {

        for(curr = theList->head; curr != NULL; curr = theList->head){

            theList->head = theList->head->next; //chop off the first node
            free(curr->data);
            free(curr);
            theList->size--;
        }
    }
}

void printList(LinkedList * theList) {

    if(theList == NULL || theList->head == NULL)
        printf("Empty List\n");
    else {

        Node *curr;
        printf("[");
        for (curr = theList->head; curr != NULL; curr = curr->next){

            if(curr->next == NULL)
                printf("%s]", curr->data);
            else
                printf("%s, ", curr->data);
        }
        printf("\n\n");
    }
}

void addLast(LinkedList * theList, Node * nn){//add Node to end of list

    Node *curr;

    if(theList->size == 0) {

        theList->head = nn;
        theList->size++;
    }

    else {

        for(curr = theList->head; curr->next != NULL; curr = curr->next);

        curr->next = nn;
        theList->size++;
    }
}

void addFirst(LinkedList * theList, Node * nn){//add Node to beginning of list

    nn->next = theList->head;
    theList->head = nn;
    theList->size++;
}

int size(LinkedList * myList){ //return LinkedList size

    if(myList == NULL)
        return 0;

    return myList->size;
}

void removeItem(LinkedList * theList, Node * nn) {

    Node *curr;
    Node *prev = theList->head;
    int data = 0;

    if(theList->size == 0) {

        return;
    }

    for(curr = theList->head; curr != NULL; prev = curr, curr = curr->next) {

        if(curr->data == nn->data) {

            if(curr == theList->head)//have to move head if removing head Node
                theList->head = curr->next;
            prev->next = curr->next;
            theList->size--;
            data = curr->data;
            free(curr);
            return data;
        }
    }
}


