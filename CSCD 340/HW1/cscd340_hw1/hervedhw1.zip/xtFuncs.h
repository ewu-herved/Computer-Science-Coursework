#ifndef XTFUNCS_H_INCLUDED
#define XTFUNCS_H_INCLUDED

int strCompare(const void * str1, const void * str2);

#endif // XTFUNCS_H_INCLUDED
