abstract class A_ComponentDynamic extends A_Component {

   public A_ComponentDynamic(DescriptorComponent descriptor) {
   
      super(descriptor);
   }
}