public interface I_Visitable {

   public void visit_(Visitor visitor);
}