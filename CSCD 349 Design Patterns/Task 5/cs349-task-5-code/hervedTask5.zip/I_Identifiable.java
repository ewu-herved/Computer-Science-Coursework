public interface I_Identifiable {

   String getID_();
}