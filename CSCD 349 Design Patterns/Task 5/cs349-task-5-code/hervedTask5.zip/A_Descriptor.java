abstract class A_Descriptor implements I_Visitable {

   
}