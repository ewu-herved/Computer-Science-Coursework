abstract class A_ComponentStatic extends A_Component{

   public A_ComponentStatic(DescriptorComponent descriptor) {
   
      super(descriptor);
   }
}