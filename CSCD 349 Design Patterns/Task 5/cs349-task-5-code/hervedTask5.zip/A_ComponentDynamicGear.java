abstract class A_ComponentDynamicGear extends A_ComponentDynamic {

   public A_ComponentDynamicGear(DescriptorComponent descriptor) {
   
      super(descriptor);
   }
}