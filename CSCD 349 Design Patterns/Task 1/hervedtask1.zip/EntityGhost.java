public class EntityGhost extends EtherealEntity {

   public EntityGhost(String id) {
   
      super(id, "floating");
   }
   
   public void initiateAttack(Entity attacked) {
   
      if(attacked instanceof EtherealEntity) {
      
         System.out.println("Sorrow of sorrows! " + getId() + " cannot meet it's fellow " +
         "even in the embrace of martial combat. What a lonely existance...");
      }
      
      else {
   
         System.out.println(getId() + " initiated supernatural attack against " + attacked.getId());
         receiveAttack(attacked);
      }
   }
}  