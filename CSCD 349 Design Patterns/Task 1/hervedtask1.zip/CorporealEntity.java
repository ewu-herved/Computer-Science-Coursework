abstract class CorporealEntity extends Entity {

   protected CorporealEntity(String id, String mode) {
   
      super(id, mode);
   }
}