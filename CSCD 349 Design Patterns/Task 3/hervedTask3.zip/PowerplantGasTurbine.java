public class PowerplantGasTurbine extends A_Powerplant {

   public PowerplantGasTurbine(String id) {
      
      super(id);
   }
      
   public String generate() {
   
      return "spinning a gas turbine\n";
   }
}