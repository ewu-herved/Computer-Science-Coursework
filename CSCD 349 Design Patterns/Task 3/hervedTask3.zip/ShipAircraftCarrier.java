public class ShipAircraftCarrier extends A_Vehicle {

   public ShipAircraftCarrier(String id, A_Powerplant powerplant) {
   
      super(id, powerplant);
   }
}