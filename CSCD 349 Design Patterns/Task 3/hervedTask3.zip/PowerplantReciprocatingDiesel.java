public class PowerplantReciprocatingDiesel extends A_Powerplant {

   public PowerplantReciprocatingDiesel(String id) {
      
      super(id);
   }
      
   public String generate() {
   
      return "chattering away\n";
   }
}