public class PowerplantNuclear extends A_Powerplant {

   public PowerplantNuclear(String id) {
      
      super(id);
   }
      
   public String generate() {
   
      return "splitting atoms\n";
   }
}