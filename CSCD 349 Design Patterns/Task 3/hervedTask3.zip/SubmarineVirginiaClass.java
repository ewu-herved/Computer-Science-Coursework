public class SubmarineVirginiaClass extends A_Vehicle {

   public SubmarineVirginiaClass(String id, A_Powerplant powerplant) {
   
      super(id, powerplant);
   }
}