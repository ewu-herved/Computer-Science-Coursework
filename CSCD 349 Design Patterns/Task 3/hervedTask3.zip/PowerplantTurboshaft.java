public class PowerplantTurboshaft extends A_Powerplant {

   public PowerplantTurboshaft(String id) {
      
      super(id);
   }
      
   public String generate() {
   
      return "spinning a shaft\n";
   }
}