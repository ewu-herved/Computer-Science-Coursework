public class PowerplantTurbofan extends A_Powerplant {

   public PowerplantTurbofan(String id) {
      
      super(id);
   }
      
   public String generate() {
   
      return "bypassing lots of air\n";
   }
}