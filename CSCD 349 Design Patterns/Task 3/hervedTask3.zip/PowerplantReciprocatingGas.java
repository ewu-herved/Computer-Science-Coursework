public class PowerplantReciprocatingGas extends A_Powerplant {

   public PowerplantReciprocatingGas(String id) {
      
      super(id);
   }
      
   public String generate() {
   
      return "vroom vroom!\n";
   }
}