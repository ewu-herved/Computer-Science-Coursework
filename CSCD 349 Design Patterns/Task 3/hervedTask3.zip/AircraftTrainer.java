public class AircraftTrainer extends A_Vehicle {

   public AircraftTrainer(String id, A_Powerplant powerplant) {
   
      super(id, powerplant);
   }
}