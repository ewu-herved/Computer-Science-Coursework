public class ShipSpeedBoat extends A_Vehicle {

   public ShipSpeedBoat(String id, A_Powerplant powerplant) {
   
      super(id, powerplant);
   }
}