public class ShipYacht extends A_Vehicle {

   public ShipYacht(String id, A_Powerplant powerplant) {
   
      super(id, powerplant);
   }
}