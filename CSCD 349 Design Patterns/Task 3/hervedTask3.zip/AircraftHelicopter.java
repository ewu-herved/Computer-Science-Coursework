public class AircraftHelicopter extends A_Vehicle {

   public AircraftHelicopter(String id, A_Powerplant powerplant) {
   
      super(id, powerplant);
   }
}