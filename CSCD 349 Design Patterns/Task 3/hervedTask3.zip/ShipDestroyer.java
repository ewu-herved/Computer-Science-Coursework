public class ShipDestroyer extends A_Vehicle {

   public ShipDestroyer(String id, A_Powerplant powerplant) {
   
      super(id, powerplant);
   }
}