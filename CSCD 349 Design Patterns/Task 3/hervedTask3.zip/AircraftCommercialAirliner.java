public class AircraftCommercialAirliner extends A_Vehicle {

   public AircraftCommercialAirliner(String id, A_Powerplant powerplant) {
   
      super(id, powerplant);
   }
}