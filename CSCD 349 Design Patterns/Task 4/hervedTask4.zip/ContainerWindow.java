import java.awt.Point;
import java.awt.Dimension;

public class ContainerWindow extends A_Container {

   public ContainerWindow(String id, Point origin, Dimension size) {
      
      super(id, origin, size);
   }
}