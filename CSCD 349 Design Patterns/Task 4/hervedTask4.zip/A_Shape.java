abstract class A_Shape extends A_Entity {

   public A_Shape(String id) {

        super(id);
   }
}