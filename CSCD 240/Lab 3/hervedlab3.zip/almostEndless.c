#include <stdio.h>
int main()
{
int x = 0;
while(x < 20)
{
printf("..");
fflush(stdout);
sleep(2);
x++;
}// end while
return 0;
}// end main
