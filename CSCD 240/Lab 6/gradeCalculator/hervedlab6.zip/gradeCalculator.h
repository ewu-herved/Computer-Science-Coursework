#ifndef GRADECALCULATOR_H_INCLUDED
#define GRADECALCULATOR_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define BUFFERSIZE 100

void readFile();

#endif // GRADECALCULATOR_H_INCLUDED
