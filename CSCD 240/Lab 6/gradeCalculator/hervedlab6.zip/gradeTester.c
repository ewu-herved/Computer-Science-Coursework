#include "gradeCalculator.h"

int main(int argc, char *argv[])
{
    readFile();

    return 0;
}
