public class PascalTester {

   public static void main(String[] args) {
   
   
   PascalTriangle tri = new PascalTriangle(15); 
   
   System.out.println(tri.toString());
   }
}