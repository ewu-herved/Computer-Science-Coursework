public interface ListInterface {

   boolean isEmpty();
   
   int getSize();
   
   void addNode(Object o);
   
   void addNode(int index, Object o);
   
   void removeNode(int index);
   
   void removeAll();
   
   String toString();
   
   public class Node {
   
      Object item;
      
      Node next;
      
      public Node(Object item) {
      
         this.item = item;
      }
      
      public Node(Object item, Node next) {
      
         this.item = item;
         this.next = next;
      }
      
      public Object getItem() {
      
         return item;
      }
      
      public Node getNext() {
      
         return next;
      }
      
      public void setItem(Object item) {
         
         this.item = item;
      }
      
      public void setNext(Node next) {
      
         this.next = next;
      }
      
      public String toString() {
      
         return next.toString();
      }
   }
}
