interface Stack {
   
   abstract boolean isEmpty();
   
   abstract void push(Comparable data);
   
   abstract Comparable pop();
}