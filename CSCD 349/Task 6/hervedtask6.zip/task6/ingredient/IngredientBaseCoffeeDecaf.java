package task6.ingredient;
import task6.money.Money;

public class IngredientBaseCoffeeDecaf extends A_IngredientBase {

   public IngredientBaseCoffeeDecaf() {
   
      super(new Money(1, 35), "coffee decaf");
   }
}