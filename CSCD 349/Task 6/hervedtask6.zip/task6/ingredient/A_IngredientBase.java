package task6.ingredient;
import task6.money.Money;

public abstract class A_IngredientBase extends A_Ingredient {

   public A_IngredientBase(Money cost, String description) {
   
      super(cost, description);
   }
}