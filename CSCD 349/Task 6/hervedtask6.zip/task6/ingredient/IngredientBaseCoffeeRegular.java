package task6.ingredient;
import task6.money.Money;

public class IngredientBaseCoffeeRegular extends A_IngredientBase {

   public IngredientBaseCoffeeRegular() {
   
      super(new Money(1, 50), "coffee regular");
   }
}