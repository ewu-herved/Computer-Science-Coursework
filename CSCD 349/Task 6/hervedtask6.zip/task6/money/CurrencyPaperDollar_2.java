package task6.money;

public class CurrencyPaperDollar_2 extends A_CurrencyPaper {

   public CurrencyPaperDollar_2() {
   
      super(new Money(200), "two");
   }
}