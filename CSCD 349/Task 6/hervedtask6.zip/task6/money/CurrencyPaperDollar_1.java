package task6.money;

public class CurrencyPaperDollar_1 extends A_CurrencyPaper {

   public CurrencyPaperDollar_1() {
   
      super(new Money(100), "single");
   }
}