package task6.money;

public abstract class A_CurrencyCoin extends A_Currency {

   public A_CurrencyCoin(Money money, String description) {
   
      super(money, description);
   }
}