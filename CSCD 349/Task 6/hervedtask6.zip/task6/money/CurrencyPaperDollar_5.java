package task6.money;

public class CurrencyPaperDollar_5 extends A_CurrencyPaper {

   public CurrencyPaperDollar_5() {
   
      super(new Money(500), "five");
   }
}