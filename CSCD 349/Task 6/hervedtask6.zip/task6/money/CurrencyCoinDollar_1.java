package task6.money;

public class CurrencyCoinDollar_1 extends A_CurrencyCoin {

   public CurrencyCoinDollar_1() {
   
      super(new Money(100), "dollar coin");
   }
}