package f14cs349task2.contracts;

//=============================================================================================================================================================
/**
 * Defines the contract for something that can attack a bird on the ground.
 * 
 * @author Dan Tappan [02.10.14]
 */
public interface I_CanAttackBirdGround extends I_CanAttackBird
{
}
