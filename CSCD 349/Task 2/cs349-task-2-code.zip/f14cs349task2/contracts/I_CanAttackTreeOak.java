package f14cs349task2.contracts;

//=============================================================================================================================================================
/**
 * Defines the contract for something that can attack an oak tree.
 * 
 * @author Dan Tappan [02.10.14]
 */
public interface I_CanAttackTreeOak extends I_CanAttackTree
{
}
