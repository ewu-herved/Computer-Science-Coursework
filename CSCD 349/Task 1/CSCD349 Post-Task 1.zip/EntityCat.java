public class EntityCat extends CorporealEntity {

   public EntityCat(String id) {
   
      super(id, "slinking");
   }
   
   public void initiateAttack(Entity attacked) {
   
      if(attacked instanceof EtherealEntity) {
      
         System.out.println("Invalid attack: " + getId() + " cannot attack ethereal entities.\n");
      }
      
      else {
   
         System.out.println(getId() + " initiated clawing attack against " + attacked.getId() + "\n");
         receiveAttack(attacked);
      }
   }  
}