public class EntityGhost extends EtherealEntity {

   public EntityGhost(String id) {
   
      super(id, "floating");
   }
   
   public void initiateAttack(Entity attacked) {
   
      if(attacked instanceof EtherealEntity) {
      
         System.out.println("Invalid attack: " + getId() + " cannot attack ethereal entities.\n");
      }
      
      else {
   
         System.out.println(getId() + " initiated supernatural attack against " + attacked.getId() + "\n");
         receiveAttack(attacked);
      }
   }
}  