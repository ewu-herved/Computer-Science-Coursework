abstract class EtherealEntity extends Entity {

   protected EtherealEntity(String id, String mode) {
   
      super(id, mode);
   }
}