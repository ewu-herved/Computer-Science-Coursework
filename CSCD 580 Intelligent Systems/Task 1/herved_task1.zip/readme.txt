To run the solution, load it into eclipse with the correct libraries included. 

I did not implement a commandline interface yet, but you can call each test in main. There is a method 
main for each test. All 5 tests take a number of lines (int) as the first parameter and an interval (int)
as the second parameter. The naming convention for the methods is hervetest[1-5]+(int, int)

main is located in CS480Task1Driver.java